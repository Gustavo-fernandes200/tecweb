function alterarTexto() {
    var elemento = document.getElementById('titulo');
    elemento.textContent = 'Novo Texto Alterado!';
}