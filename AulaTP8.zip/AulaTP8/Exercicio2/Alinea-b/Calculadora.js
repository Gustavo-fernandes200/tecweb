
            function calcularSoma() {
                var valor1 = parseFloat(document.getElementById("valor1").value);
                var valor2 = parseFloat(document.getElementById("valor2").value);
                var soma = valor1 + valor2;
                window.alert("A soma de " + valor1 + " e " + valor2 + " é igual a " + soma);
            }


