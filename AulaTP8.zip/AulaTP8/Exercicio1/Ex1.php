<html>
    <head>
        <title>
            Teste PHP
        </title>
    </head>
    <body>
        <?php echo "<p>Olá Mundo</p>"; ?>
    </body>
</html>
