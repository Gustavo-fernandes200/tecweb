<form action="checkbox.php" method="post">
    <b>Escolha alguns números:</b><br>
        <input type="checkbox" name="numeros[]" value="10"> 10<br>
        <input type="checkbox" name="numeros[]" value="100"> 100<br>
        <input type="checkbox" name="numeros[]" value="1000"> 1000<br>
        <input type="checkbox" name="numeros[]" value="10000"> 10000<br>
        <input type="checkbox" name="numeros[]" value="90"> 90<br>
        <input type="checkbox" name="numeros[]" value="50"> 50<br>
        <input type="checkbox" name="numeros[]" value="30"> 30<br>
        <input type="checkbox" name="numeros[]" value="15"> 15<br><br>
        <input type="checkbox" name="news" value="1"> <b>Receber
    Newsletter?</b><br><br>
    <input type="submit">
</form>