<?php
    // Assuming today is March 10th, 2024, 5:16:18 pm
    $today = date("F j, Y, g:i a"); // March 10, 2024, 5:16 pm
    $today = date("m.d.y"); // 03.10.01
    $today = date("j, n, Y"); // 10, 3, 2024
    $today = date("Ymd"); // 20240310
    $today = date('h-i-s, j-m-y, it is w Day z'); // 05-16-17, 10-03-24,
    1631 1618 6 Fri pm24
    $today = date('\i\t \i\s \t\h\e jS \d\a\y.'); // It is the 10th
?>
